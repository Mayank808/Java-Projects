/*
 ----------------------------------------------------------
 Author: Mayank Mehra 
 Date: Friday July 12, 2019
 Purpose: Using ASCII code in a program
 ----------------------------------------------------------
 Description: Ask a user for a secret message. (Around 15 characters)
 Incorporate the program code shown above. Use the user's input and 
 translate the message from English to ACSII values (with spaces),
 e.g., the message CAT encodes to 67 65 84. Then convert your ASCII values 
 to binary and output the values.
 ----------------------------------------------------------
 */
package Assignment1_Bits_and_Bytes;

import java.util.Scanner;

public class Assignment1_Bits_and_Bytes {

    public static void main(String[] args) {

        //Declare Variables 
        String strSecretMessage, strFinalMessage = ""; //SecretMessage will hold input while Final Message will hold the output
        int intAsciiValue; //holds Ascii value of useres input
        Scanner scnSecretMessage; //Input Scanner
        scnSecretMessage = new Scanner(System.in);//SetupScanner to look for input 

        System.out.println("Welcome Agent\n\nEnter Message Below to be Encoded in Binary (1-15 Characters)....");
        strSecretMessage = scnSecretMessage.next(); //input from scanner is stored in SecretMessage

        for (int i = 0; i < strSecretMessage.length(); i++) { //loop setup to look at each letter on its own in the inputed string
            intAsciiValue = (int) strSecretMessage.charAt(i); // converts and stores the Ascii value of the input

            strFinalMessage = strFinalMessage + " " + Integer.toBinaryString(intAsciiValue);
            // ^ saves it to the output FinalMessage/Converts the Integers to Binary String/ Lastly, makes sure that all the bianary are in one line and have spaces inbetween them

        }
        System.out.println("Your encoded Message in Binary is:\n" + strFinalMessage); //Output Statement

    }

}

/*
----------------------------------------------------------
Author: Mayank Mehra 
Date: Friday July 5, 2019
Purpose:Using Math Class in a Program 
----------------------------------------------------------
Description: Discover and make use of several additional Math methods.
----------------------------------------------------------
 */
package Unit2_Activity3;

public class U2_A3_MathClass {
    public static void main(String[] args) {
         // Declare Variables
        double myNumber1, myNumber2, cuberoot, hypotenuse,logs, angledegrees, angleradians; 
        double squareRoot, highestValue, circleArea,randomNumber, lowestnumber;

        System.out.println("Math Class Methods");
        System.out.println("******************\n");

        // round() Method
        myNumber1 = Math.round(7.5342);
        System.out.println("7.5342 is rounded to " + myNumber1 );
        myNumber2=Math.round(10.4999);
        System.out.println("10.4999 is rounded to " + myNumber2 + "\n");

        // sqrt() Method
        squareRoot=Math.sqrt(36);
        System.out.println("The squareroot of 36 is " + squareRoot + "\n");

        // max() Method
        highestValue=Math.max(10,20);
        System.out.println("The maximum value of 10,20 is " + highestValue + "\n");

        // This example uses several Math Methods and a Math constant - PI
        circleArea=Math.round(Math.PI * Math.pow(8,2));
        System.out.println("The area of a circle with a radius of 8 is " + circleArea + "\n");

        // random() Method
        randomNumber = Math.random();
        System.out.println("The random number generated is: " + randomNumber + "\n");
    
//My Added Methods 
        //min() Method
        lowestnumber = Math.min(2,9);
        System.out.println("The Lowest number out of the set is "+ lowestnumber+ "\n");
        
        //cbrt() Method
        cuberoot = Math.cbrt(27);
        System.out.println("The Cuberoot of 27 is "+cuberoot+"\n");
        
        //hypot() Method
        hypotenuse = Math.hypot(myNumber1,myNumber2); 
        hypotenuse = Math.round(hypotenuse); 
        System.out.println("The hypotenuse of this triangle is " + hypotenuse + "cm\n");
        
        //log10() Method
        logs= Math.log10(10000); 
        System.out.println("The log10 of 10000 is "+ logs + "\n");
        
       //toradians() 
       angledegrees = Math.toRadians(90);
       angledegrees = Math.round(angledegrees);
       System.out.print("90 degrees in radians is " + angledegrees + " rads \n");
       
       //todegrees()
       angleradians = Math.toDegrees(3.141592654);
       angleradians = Math.round(angleradians);
       System.out.print("Pi radians converted to degrees is " + angleradians + " degrees \n");
       
       
        
        
    }
}

    

       
                
                
          
                
     
      



        
  
    


    


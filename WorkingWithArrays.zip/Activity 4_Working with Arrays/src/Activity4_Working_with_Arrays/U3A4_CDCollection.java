/*
 ----------------------------------------------------------
 Author: Mayank Mehra 
 Date: Friday July 15, 2019
 Purpose: Working with Arrays
 ----------------------------------------------------------
 Description: Create a program to help you to keep track of your CD collection.
 ----------------------------------------------------------
 */
package Activity4_Working_with_Arrays;

//imports
import java.util.ArrayList;
import java.util.Collections;

public class U3A4_CDCollection extends javax.swing.JFrame {
    //Declare the array as a global variable 
    ArrayList<String> ArrSongs = new ArrayList();

    public U3A4_CDCollection() {
        initComponents();
        btnDisplay.setEnabled(false); //the program starts with these buttons off
        btnAdd.setEnabled(false);
        btnRemove.setEnabled(false);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitle = new javax.swing.JLabel();
        lblNaming = new javax.swing.JLabel();
        txtNames = new javax.swing.JTextField();
        btnDisplay = new javax.swing.JButton();
        btnInitialize = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtOutputBox = new javax.swing.JTextArea();
        btnAdd = new javax.swing.JButton();
        btnRemove = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        lblTitle.setBackground(new java.awt.Color(255, 102, 102));
        lblTitle.setFont(new java.awt.Font("Lucida Grande", 1, 24)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(255, 102, 102));
        lblTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitle.setText("CD Collection");
        getContentPane().add(lblTitle);
        lblTitle.setBounds(0, 6, 579, 30);

        lblNaming.setText("Title - Artist");
        getContentPane().add(lblNaming);
        lblNaming.setBounds(41, 60, 79, 16);
        getContentPane().add(txtNames);
        txtNames.setBounds(132, 54, 377, 28);

        btnDisplay.setText("Display");
        btnDisplay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDisplayActionPerformed(evt);
            }
        });
        getContentPane().add(btnDisplay);
        btnDisplay.setBounds(41, 100, 100, 29);

        btnInitialize.setText("Initialize");
        btnInitialize.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInitializeActionPerformed(evt);
            }
        });
        getContentPane().add(btnInitialize);
        btnInitialize.setBounds(147, 100, 98, 29);

        txtOutputBox.setEditable(false);
        txtOutputBox.setColumns(20);
        txtOutputBox.setLineWrap(true);
        txtOutputBox.setRows(5);
        txtOutputBox.setWrapStyleWord(true);
        jScrollPane1.setViewportView(txtOutputBox);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(41, 135, 501, 372);

        btnAdd.setText("Add");
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });
        getContentPane().add(btnAdd);
        btnAdd.setBounds(353, 100, 90, 29);

        btnRemove.setText("Remove");
        btnRemove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoveActionPerformed(evt);
            }
        });
        getContentPane().add(btnRemove);
        btnRemove.setBounds(449, 100, 93, 29);

        jPanel1.setBackground(new java.awt.Color(51, 255, 204));
        jPanel1.setForeground(new java.awt.Color(255, 153, 51));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 580, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 540, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 580, 540);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnDisplayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDisplayActionPerformed
        txtOutputBox.setText(null); //gets ride of any text within the text area
        DisplaySortedSongs(ArrSongs); //inputs the array using the Method 
    }//GEN-LAST:event_btnDisplayActionPerformed


    private void btnInitializeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInitializeActionPerformed
        //Adds preset songs into the array 
        Collections.addAll(ArrSongs, "Metric - Fantasies", "Beatles - Abbey Road", "Pearl Jam - Ten",
                "Doors -Alive", "The Rolling Stones - Gimme Shelter");
        DisplaySongs(ArrSongs); //Displays array in text area using method

        btnDisplay.setEnabled(true); //turns the other 3 buttons on whne this button is pressed
        btnAdd.setEnabled(true);
        btnRemove.setEnabled(true);
        btnInitialize.setEnabled(false);//closese this button off when pressed

    }//GEN-LAST:event_btnInitializeActionPerformed

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed
        String strMovetoArray = this.txtNames.getText(); //gets text from Input and stores it 
        ArrSongs.add(strMovetoArray); //adds the input into the array
        txtOutputBox.setText(null); //emptys the txtArea
        txtOutputBox.setText("The Song has been added\nPress display to view the updated List"); //displays this
    }//GEN-LAST:event_btnAddActionPerformed

    private void btnRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRemoveActionPerformed
        String strRemoveArray = this.txtNames.getText(); //stores input 
        int intPositionofRemovedSong = ArrSongs.indexOf(strRemoveArray); //stores index of the song in the arraylist
        if (intPositionofRemovedSong == -1) { //if song doesn't exist the index will be -1
            txtOutputBox.setText("This song was not found.\nPlease make sure that you spelled it correclty and have the right spaces.\nTry Again Please!");
        } else if (intPositionofRemovedSong >= 0) { //if song does exist the index will be greater then or equal to 0
            ArrSongs.remove(intPositionofRemovedSong); //removes song
            txtOutputBox.setText("This Song Has been Removed\nPress display to view the updated List");
        }


    }//GEN-LAST:event_btnRemoveActionPerformed

    private ArrayList DisplaySongs(ArrayList String) { //display unsorted string array method and only takes stringed array lists
        txtOutputBox.append("  Original Order\n\n"); 
        for (int i = 0; i < String.size(); i++) { //Displays songs and numbers them 
            txtOutputBox.append(Integer.toString(i + 1) + ". " + String.get(i) + "\n");
        }
        return String;
    }

    private ArrayList DisplaySortedSongs(ArrayList String) { //displays sorted 
        txtOutputBox.append("  Sorted Order\n\n");
        Collections.sort(String); //sorts the songs in order 
        for (int i = 0; i < String.size(); i++) { //Displays songs and numbers them 
            txtOutputBox.append(Integer.toString(i + 1) + ". " + String.get(i) + "\n");
        }
        return String;

    }

    public static void main(String args[]) {

        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(U3A4_CDCollection.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(U3A4_CDCollection.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(U3A4_CDCollection.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(U3A4_CDCollection.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new U3A4_CDCollection().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnDisplay;
    private javax.swing.JButton btnInitialize;
    private javax.swing.JButton btnRemove;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblNaming;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JTextField txtNames;
    private javax.swing.JTextArea txtOutputBox;
    // End of variables declaration//GEN-END:variables
}

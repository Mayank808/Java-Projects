/*
 ----------------------------------------------------------
 Author: Mayank Mehra 
 Date: Friday July 15, 2019
 Purpose: Using the Bubble Sort Algorithm
 ----------------------------------------------------------
 Description: Create a program that asks a user for a number of integers.  
 The program will then ask the user to input as many integers as the 
 user requested and fill the values of the arrays into it.  
 ----------------------------------------------------------
 */
package Activity4_Working_with_Arrays;
//Imports

import java.util.Scanner;
import java.text.DecimalFormat;

public class U3A4_Bubbles {

    //Make ArrValues a global variable so I can use it anywhere in the program

    static int[] ArrValues;

    public static void main(String[] args) {
        //Declare Variables, Scanners, DecimalFormat
        int intNumberofValues, intValues, intMiddle, intsum = 0;
        double dblMedianValue, dblAverage;
        DecimalFormat dfRound = new DecimalFormat("######.00");
        Scanner scnNumberofValues, scnValues;
        //Setup Scanners
        scnNumberofValues = new Scanner(System.in);
        scnValues = new Scanner(System.in);
/***************************************************************************************************/
        //Take User Input to find how big the array is
        System.out.print("Please enter the number of values you would like to enter: ");
        intNumberofValues = scnNumberofValues.nextInt();
        ArrValues = new int[intNumberofValues]; //asign the amount of spots in the array

        for (int i = 0; i < intNumberofValues; i++) { //Input and stores all the values being put in the array 
            System.out.print("Please enter for index value of " + i + ": ");
            ArrValues[i] = scnValues.nextInt();
            intsum = intsum + ArrValues[i]; //Finds the summ of the values so it can be used for the average later
        }
/***************************************************************************************************/
        System.out.print("\nHere is your Unsorted List: "); //Displays the unsorted list of numbers
        for (int i = 0; i < intNumberofValues; i++) { //for loop was done to help display numbers and commas properly
            if (i < intNumberofValues - 1) {
                System.out.print(ArrValues[i] + ", ");
            } else if (i == intNumberofValues - 1) { // stops putting commas when the loop gets to the last number
                System.out.print(ArrValues[i]);
            } else { //just incase anything goes worng (good practise)
                System.out.print("Error Restart Program");
            }
        }
/***************************************************************************************************/
        System.out.print("\nHere is your Sorted List: "); // Displays the Sorted list of numbers
        bubbleSort(); //Access method to do the sorting
        for (int i = 0; i <= intNumberofValues - 1; i++) { //for loop was done to help display numbers and commas properly
            if (i < intNumberofValues - 1) {
                System.out.print(ArrValues[i] + ", ");
            } else if (i == intNumberofValues - 1) { // stops putting commas when the loop gets to the last number
                System.out.print(ArrValues[i]);
            } else { //just incase anything goes worng (good practise)
                System.out.print("Error Restart Program");
            }
        }
/***************************************************************************************************/
        System.out.println("\nGreatest number: " + ArrValues[intNumberofValues - 1]); //Gets the the Greatest Number
        System.out.println("Smallest number: " + ArrValues[0]);//Gets the smallest number
        System.out.print("Median number: ");//Figure out median

        intMiddle = (ArrValues.length) / 2; //Divides the amount of numbers by 2
        if (ArrValues.length % 2 == 1) { //gets remainder of the amount of numbers to check if there an Odd amount
            dblMedianValue = (double) ArrValues[intMiddle]; //odd amount of numbers - display the middle number 
            System.out.print(dblMedianValue + "\n");
        } else if (ArrValues.length % 2 == 0) { //gets remainder of the amount of numbers to check if there an Even amount
            dblMedianValue = (double) (ArrValues[intMiddle - 1] + ArrValues[intMiddle]) / 2; //even amount - divide the two middle numbers to find median
            System.out.print(dblMedianValue + "\n");
        }
        dblAverage = (double) intsum / intNumberofValues; //Use sum calculated from before and divide by amount of numbers
        System.out.print("Average: " + dfRound.format(dblAverage) + "\n"); //round and display value 
    }
/***************************************************************************************************/
    public static int[] bubbleSort() { //bubble sort ordering method
        int i, j, temp;
        for (i = 0; i < ArrValues.length - 1; i++) {
            for (j = 0; j < ArrValues.length - 1 - i; j++) {
                if (ArrValues[j] > ArrValues[j + 1]) {
                    temp = ArrValues[j];
                    ArrValues[j] = ArrValues[j + 1];
                    ArrValues[j + 1] = temp;
                }
            }
        }
        return ArrValues;
    }

}

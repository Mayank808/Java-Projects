/*
----------------------------------------------------------
Author: Mayank Mehra 
Date: Friday July 5, 2019
Purpose:Using Math Class in a Program 
----------------------------------------------------------
Description: Write a short program that calculates your bill at a restaurant.
----------------------------------------------------------
 */
//importing a scanner and rounding formatting
import java.text.*;
import java.util.Scanner;

public class U2_A3_BillJava {

    public static void main(String[] args) {
        //setting up varibles and scanner 
        double dblMealCost,dblHST,dblTotal;
        Scanner scnMealCost = new Scanner(System.in);
        
        System.out.println("Enter Meal Cost (Exclude $): ");
      
        // assiging values to varibales 
        dblMealCost= scnMealCost.nextDouble();
        dblHST = dblMealCost * .13 ; 
        dblTotal = dblMealCost + dblHST; 
        
        //rounding and formating
        DecimalFormat dfMealCost = new DecimalFormat ("$###.00");
        DecimalFormat dfHST = new DecimalFormat ("$###.00");
        DecimalFormat dfTotal = new DecimalFormat ("$###.00"); 
                
        //all output
        System.out.println("\nPrinting Recipt....\n");
        System.out.println("The Cheesecake Factory Recipt\n");
        System.out.println("Cost:\t\t\t" + dfMealCost.format(dblMealCost));
        System.out.println("HST:\t\t\t" + dfHST.format(dblHST));
        System.out.println("------------------------------");
        System.out.println("Total:\t\t\t" + dfTotal.format(dblTotal) + "\n");
        System.out.println("  Thank you for dining at\n   The Cheesecake Factory!! ");
        
  
    }
    
}

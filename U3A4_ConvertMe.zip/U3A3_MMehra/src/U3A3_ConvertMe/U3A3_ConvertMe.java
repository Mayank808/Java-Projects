/*
----------------------------------------------------------
Author: Mayank Mehra 
Date: Friday July 15, 2019
Purpose: Turning Recurring Code into Functions
----------------------------------------------------------
Description: Create a program that displays the title “Linear Conversion”,
    a menu of conversion choices, and two input boxes. Each conversion must 
    be done in a separate method. Use parameter passing and return values back 
    to the method call. Display all answers to 2 decimal places.
----------------------------------------------------------
 */
package U3A3_ConvertMe;

import java.text.DecimalFormat; //imported the DecimalFormat class

public class U3A3_ConvertMe extends javax.swing.JFrame {

    DecimalFormat dfRound;

    public U3A3_ConvertMe() {
        this.dfRound = new DecimalFormat("######.00"); //Declare dfRound as a global Variable
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitle = new javax.swing.JLabel();
        cbConversion = new javax.swing.JComboBox();
        lblConversion = new javax.swing.JLabel();
        lblValue = new javax.swing.JLabel();
        txtValue = new javax.swing.JTextField();
        btnConvert = new javax.swing.JButton();
        lblOutput = new javax.swing.JLabel();
        Separator = new javax.swing.JSeparator();
        jPanel1 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        lblTitle.setFont(new java.awt.Font("Lucida Grande", 1, 36)); // NOI18N
        lblTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitle.setText("Measurement Converter");
        getContentPane().add(lblTitle);
        lblTitle.setBounds(0, 10, 570, 43);

        cbConversion.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        cbConversion.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Inches to Centimetres", "Feet to Centimetres", "Yards to Metres", "Miles to Kilometres", "Centimetres to Inches", "Centimetres to Feet", "Metres to Yards", "Kilometres to Miles", " " }));
        cbConversion.setSelectedItem(null);
        cbConversion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbConversionActionPerformed(evt);
            }
        });
        getContentPane().add(cbConversion);
        cbConversion.setBounds(260, 80, 240, 40);

        lblConversion.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        lblConversion.setText("Enter Conversion Choice: ");
        getContentPane().add(lblConversion);
        lblConversion.setBounds(60, 90, 230, 17);

        lblValue.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        lblValue.setText("Enter Value to be Converted: ");
        getContentPane().add(lblValue);
        lblValue.setBounds(60, 180, 230, 17);

        txtValue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtValueActionPerformed(evt);
            }
        });
        getContentPane().add(txtValue);
        txtValue.setBounds(280, 170, 240, 30);

        btnConvert.setText("Convert");
        btnConvert.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConvertActionPerformed(evt);
            }
        });
        getContentPane().add(btnConvert);
        btnConvert.setBounds(280, 210, 240, 29);

        lblOutput.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        lblOutput.setForeground(new java.awt.Color(255, 102, 102));
        lblOutput.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblOutput.setText("Metric & Imperial Converstions ");
        getContentPane().add(lblOutput);
        lblOutput.setBounds(0, 270, 570, 17);
        getContentPane().add(Separator);
        Separator.setBounds(0, 300, 570, 12);

        jPanel1.setBackground(new java.awt.Color(255, 204, 51));
        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 600, 350);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnConvertActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConvertActionPerformed
        double dblNumber = Double.parseDouble(this.txtValue.getText());
        //if else statement takes input from combo box and does that conversion 
        if (cbConversion.getSelectedItem().equals("Inches to Centimetres")) {                              
            lblOutput.setText(dblNumber + " Inches = " + InchestoCentimetres(dblNumber) + " Cenimetres"); 
            // ^ outputs the number inputed and then converts the number using a method
        } else if (cbConversion.getSelectedItem().equals("Feet to Centimetres")) {
            lblOutput.setText(dblNumber + " Feet = " + FeettoCentimetres(dblNumber) + " Cenimetres"); 
        } else if (cbConversion.getSelectedItem().equals("Yards to Metres")) {
            lblOutput.setText(dblNumber + " Yards = " + YardstoMetres(dblNumber) + " Metres");
        } else if (cbConversion.getSelectedItem().equals("Miles to Kilometres")) {
            lblOutput.setText(dblNumber + " Miles = " + MilestoKilometres(dblNumber) + " Kilometres");
        } else if (cbConversion.getSelectedItem().equals("Centimetres to Inches")) {         
            lblOutput.setText(dblNumber + " Centimetres = " + CentimetrestoInches(dblNumber) + " Inches");
        } else if (cbConversion.getSelectedItem().equals("Centimetres to Feet")) {            
            lblOutput.setText(dblNumber + " Centimetres = " + CentimetrestoFeet(dblNumber) + " Feet");
        } else if (cbConversion.getSelectedItem().equals("Metres to Yards")) {
            lblOutput.setText(dblNumber + " Metres = " + MetrestoYards(dblNumber) + " Yards");
        } else if (cbConversion.getSelectedItem().equals("Kilometres to Miles")) {
             this.lblOutput.setText(dblNumber + " Kilometres = " + KilometrestoMiles(dblNumber) + " Miles");
        } else {
            this.lblOutput.setText("Please select a conversion rate and value!");
        }
    }//GEN-LAST:event_btnConvertActionPerformed

    //the Created Private voids for every conversion are here 
    private String InchestoCentimetres(double x) {  //Output a string and uses 1 double varibles as parameters
        double y = (x * 2.54); //Calculations for conversion
        return dfRound.format(y); //returns a rounded version of the variabale          
    }

    private String FeettoCentimetres(double x) {
        double y = x * 30;
        return dfRound.format(y); 
    }

    private String YardstoMetres(double x) {       
        double y = x * 0.91;
        return dfRound.format(y); 
    }

    private String MilestoKilometres(double x) {        
        double y = x * 1.60;
        return dfRound.format(y); 
    }

    private String CentimetrestoInches(double x) {
        double y = x / 2.54;   
        return dfRound.format(y); 
    }

    private String CentimetrestoFeet(double x) {
        double y = x / 30;
        return dfRound.format(y);      
    }

    private String MetrestoYards(double x) { 
        double y = x / 0.91;
        return dfRound.format(y); 
    }

    private String KilometrestoMiles(double x) {
        double y  = x / 1.6;
        return dfRound.format(y);       
    }
    private void cbConversionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbConversionActionPerformed

    }//GEN-LAST:event_cbConversionActionPerformed

    private void txtValueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtValueActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtValueActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(U3A3_ConvertMe.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(U3A3_ConvertMe.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(U3A3_ConvertMe.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(U3A3_ConvertMe.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new U3A3_ConvertMe().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JSeparator Separator;
    private javax.swing.JButton btnConvert;
    private javax.swing.JComboBox cbConversion;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblConversion;
    private javax.swing.JLabel lblOutput;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JLabel lblValue;
    private javax.swing.JTextField txtValue;
    // End of variables declaration//GEN-END:variables
}

/*
----------------------------------------------------------
Author: Mayank Mehra 
Date: Friday July 12, 2019
Purpose: Ideal Weight Calculator Summative
----------------------------------------------------------
Description: The program will use the person's height to calculate his/her 
    ideal healthy weight using a formula produced from the formula for body mass 
    index (BMI). 
----------------------------------------------------------
 */

package Unit_2_Summative;

import java.text.DecimalFormat; //imported to use Decimal format for rounding 

public class Ideal_Weight_Calculator extends javax.swing.JFrame {

    
    public Ideal_Weight_Calculator() {
        initComponents();
    }

 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitle = new javax.swing.JLabel();
        lblName = new javax.swing.JLabel();
        txtName = new javax.swing.JTextField();
        lblSystem = new javax.swing.JLabel();
        lblMeasure = new javax.swing.JLabel();
        txtSystem = new javax.swing.JTextField();
        lblHeight = new javax.swing.JLabel();
        lblHeightSystem = new javax.swing.JLabel();
        txtHeight = new javax.swing.JTextField();
        lblOutput = new javax.swing.JLabel();
        btnCalculate = new javax.swing.JButton();
        Separator = new javax.swing.JSeparator();
        Background = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        lblTitle.setFont(new java.awt.Font("Lucida Grande", 1, 36)); // NOI18N
        lblTitle.setText("Ideal Weight Calculator");
        getContentPane().add(lblTitle);
        lblTitle.setBounds(40, 10, 432, 43);

        lblName.setFont(new java.awt.Font("Damascus", 1, 14)); // NOI18N
        lblName.setText("Name:");
        getContentPane().add(lblName);
        lblName.setBounds(50, 90, 100, 20);

        txtName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNameActionPerformed(evt);
            }
        });
        getContentPane().add(txtName);
        txtName.setBounds(220, 80, 233, 30);

        lblSystem.setFont(new java.awt.Font("Damascus", 1, 14)); // NOI18N
        lblSystem.setText("System of Measure:");
        getContentPane().add(lblSystem);
        lblSystem.setBounds(50, 130, 180, 20);

        lblMeasure.setText("(M)etric or (I)mperial");
        getContentPane().add(lblMeasure);
        lblMeasure.setBounds(60, 150, 127, 20);
        getContentPane().add(txtSystem);
        txtSystem.setBounds(220, 130, 233, 30);

        lblHeight.setFont(new java.awt.Font("Damascus", 1, 14)); // NOI18N
        lblHeight.setText("Height:");
        getContentPane().add(lblHeight);
        lblHeight.setBounds(50, 200, 110, 20);

        lblHeightSystem.setText("Metres or Inches");
        getContentPane().add(lblHeightSystem);
        lblHeightSystem.setBounds(60, 220, 104, 20);
        getContentPane().add(txtHeight);
        txtHeight.setBounds(220, 200, 233, 30);

        lblOutput.setFont(new java.awt.Font("Damascus", 1, 14)); // NOI18N
        lblOutput.setText("Your Ideal Weight is......");
        getContentPane().add(lblOutput);
        lblOutput.setBounds(30, 270, 440, 70);

        btnCalculate.setText("Calculate");
        btnCalculate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCalculateActionPerformed(evt);
            }
        });
        getContentPane().add(btnCalculate);
        btnCalculate.setBounds(290, 240, 165, 30);
        getContentPane().add(Separator);
        Separator.setBounds(0, 340, 513, 10);

        Background.setBackground(new java.awt.Color(255, 102, 102));
        getContentPane().add(Background);
        Background.setBounds(0, 0, 560, 420);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNameActionPerformed
       
    }//GEN-LAST:event_txtNameActionPerformed

    private void btnCalculateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCalculateActionPerformed
        
        //Declare Variables
        double dblHeight, dblWeightMetric, dblWeightImperial;
        dblHeight = Double.parseDouble(this.txtHeight.getText()); //Grabs the input from txtHeight and stores it 
        String strName = this.txtName.getText();  //takes name entered from txtName and stores it
        DecimalFormat dfRound = new DecimalFormat ("####.00"); //creates a rounding format
        
        switch (this.txtSystem.getText()) {
            case "M": case "m": //allows for both M and m to work when entered
            {
               dblWeightMetric = Math.pow(dblHeight,2) * 25; 
               this.lblOutput.setText(strName + (", Your Ideal Weight is " +dfRound.format(dblWeightMetric) + "kgs"));
               break; 
            }
            case "I": case "i": //allows for both I and i to work when entered
            {
               dblWeightImperial = (Math.pow(dblHeight,2) * 25)/703; 
               this.lblOutput.setText(strName + (", Your Ideal Weight is " + dfRound.format(dblWeightImperial) + "lbs")); 
               break;
            }       
        }

               
    }//GEN-LAST:event_btnCalculateActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Ideal_Weight_Calculator.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Ideal_Weight_Calculator.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Ideal_Weight_Calculator.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Ideal_Weight_Calculator.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Ideal_Weight_Calculator().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Background;
    private javax.swing.JSeparator Separator;
    private javax.swing.JButton btnCalculate;
    private javax.swing.JLabel lblHeight;
    private javax.swing.JLabel lblHeightSystem;
    private javax.swing.JLabel lblMeasure;
    private javax.swing.JLabel lblName;
    private javax.swing.JLabel lblOutput;
    private javax.swing.JLabel lblSystem;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JTextField txtHeight;
    private javax.swing.JTextField txtName;
    private javax.swing.JTextField txtSystem;
    // End of variables declaration//GEN-END:variables
}

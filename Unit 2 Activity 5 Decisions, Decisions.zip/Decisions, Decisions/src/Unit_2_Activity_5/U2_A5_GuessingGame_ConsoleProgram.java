/*
----------------------------------------------------------
Author: Mayank Mehra 
Date: Friday July 9, 2019
Purpose: Boolean Guessing Game Program
----------------------------------------------------------
Description: Create a guessing game application, where the computer 
    picks a random number between 1 and 100 and lets you keep guessing 
    until you get it right!  You can do this either as a console program 
    or as a GUI program.
----------------------------------------------------------
 */

package Unit_2_Activity_5;

//imports for Scanner and random number generator
import java.util.Random;
import java.util.Scanner;

public class U2_A5_GuessingGame_ConsoleProgram {
    

     public static void main(String[] args) {
        
        //Declare Variables & Scanner
        Random randomNum = new Random();
        int intRangemax = 100,intRangemin = 1,intNumber,intGuess;
        Scanner scnGuess; 
        intNumber = intRangemin + randomNum.nextInt(intRangemax);    
        scnGuess = new Scanner(System.in);
        
        //Output initial Display
        System.out.println("\tWelcome to Guess the Number!\n\n  The aim of the game is to guess the number"
                + "\n\t I am thinking of between 1-100.\n");
        
        //loop 
        while(true) {
            
        //Scanner Setup    
        System.out.println("Enter your Guess Below:");
        intGuess = scnGuess.nextInt();
        
        //if else statements to help hint the guesser
        if (intGuess == intNumber)  
        {
            System.out.println("You Got it! We have a WINNER"); 
            break; 
        }    
        else if ((intGuess >= intNumber - 4) && (intGuess <= intNumber + 4))  
        {
            System.out.println("Boiling");       
        }    
        else if ((intGuess >= intNumber - 5) && (intGuess <= intNumber + 5))  
        {
            System.out.println("Hot");  
        }    
        else if ((intGuess >= intNumber - 10) && (intGuess <= intNumber + 10))  
        {
            System.out.println("Warm");       
        }    
        else if ((intGuess >= intNumber - 15) && (intGuess <= intNumber + 15))    
        {
            System.out.println("Cool"); 
        }
        else if ((intGuess >= intNumber - 25) && (intGuess <= intNumber + 25))              
        {
            System.out.println("Cold");
        }
        else if ((intGuess >= intNumber - 50) && (intGuess <= intNumber + 50))
        {
            System.out.println("Freezing"); 
        }
        else 
        {
            System.out.println("Try Again");
        }
        
        }
    }
}
   

    
    
      
       
             
    
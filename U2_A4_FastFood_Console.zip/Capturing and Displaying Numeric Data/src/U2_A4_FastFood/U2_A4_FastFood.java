/*
----------------------------------------------------------
Author: Mayank Mehra 
Date: Friday July 8, 2019
Purpose: Using Input Feilds in a program
----------------------------------------------------------
Description: Create an order application that provides the employee 
    with input fields to enter the number of burgers, fries, 
    and soft drinks that a customer orders.
----------------------------------------------------------
 */

package U2_A4_FastFood;

import java.text.*;
import java.util.Scanner;

public class U2_A4_FastFood {

    public static void main(String[] args) {
    
        //Declare Varibales
        double dblBurger, dblFries, dblSoftDrinks, dblCost, dblHST, dblTotal,dblAmountTendered, dblChange; 
        Scanner scnBurger, scnFries, scnSoftDrinks, scnAmountTendered; 
    
        //SetupScanners
        scnBurger = new Scanner(System.in);
        scnFries = new Scanner(System.in); 
        scnSoftDrinks = new Scanner(System.in);
        scnAmountTendered = new Scanner(System.in);

        //input feilds setup 
        System.out.println("Enter the number of Burgers:");  
        dblBurger = scnBurger.nextDouble() * 2.49; 
        System.out.println("Enter the number of Fries: ");  
        dblFries = scnFries.nextDouble() * 1.89;
        System.out.println("Enter the number of SoftDrinks:");
        dblSoftDrinks = scnSoftDrinks.nextDouble() * 0.99; 

        //Calculations
        dblCost = dblBurger + dblFries + dblSoftDrinks; 
        dblHST = dblCost* .13; 
        dblTotal = dblCost + dblHST;
        
        //rounding
        DecimalFormat dfRound = new DecimalFormat ("##0.00");  
        
        //Displayed Output
        System.out.println("Cost:\t\t\t$" +dfRound.format(dblCost));
        System.out.println("HST:\t\t\t$" + dfRound.format(dblHST));
        System.out.println("--------------------------------");
        System.out.println("Total Cost:\t\t$" + dfRound.format(dblTotal) + "\n"); 
        
        System.out.println("Enter Amount Tendered (Exclude $):");
        dblAmountTendered = scnAmountTendered.nextDouble();
        dblChange = dblAmountTendered - dblTotal; 

        System.out.println("\nChange Due:\t\t$" + dfRound.format(dblChange));

    }
    
}
